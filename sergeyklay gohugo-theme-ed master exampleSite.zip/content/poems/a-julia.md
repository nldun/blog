---
title: A Julia de Burgos
date: 2022-01-01T14:57:10+02:00
draft: false
author: Julia de Burgos
editor: Alex Gil
source: Ciudad Seva
lang: es
---

- Ya las gentes murmuran que yo soy tu enemiga
- porque dicen que en verso doy al mundo mi yo.
<!-- -->
- Mienten, *Julia de Burgos*. Mienten, Julia de Burgos.
- La que se alza en mis versos no es tu voz: es mi voz
- porque tú eres [ropaje](http://www.spanishdict.com/translate/ropaje) y la esencia soy yo; y el más
- profundo abismo se tiende entre las dos.
<!-- -->
- Tú eres fria muñeca de mentira social,
- y yo, viril destello de la humana verdad.
<!-- -->
- Tú, miel de cortesana hipocresías; yo no;
- que en todos mis poemas desnudo el corazón.
<!-- -->
- Tú eres como tu mundo, egoísta;
- yo no; que en todo me lo juego a ser lo que soy yo.
<!-- -->
- Tú eres sólo la grave señora señorona; yo no,
- yo soy la vida, la fuerza, la mujer.
<!-- -->
- Tú eres de tu marido, de tu amo; yo no;
- yo de nadie, o de todos, porque a todos, a
- todos en mi limpio sentir y en mi pensar me doy.
<!-- -->
- Tú te rizas el pelo y te pintas; yo no;
- a mí me riza el viento, a mí me pinta el sol.
<!-- -->
- Tú eres dama casera, resignada, sumisa,
- atada a los prejuicios de los hombres; yo no;
- que yo soy Rocinante corriendo desbocado
- olfateando horizontes de justicia de Dios.
<!-- -->
- Tú en ti misma no mandas;
- a ti todos te mandan; en ti mandan tu esposo, tus
- padres, tus parientes, el cura, el modista,
- el teatro, el casino, el auto,
- las alhajas, el banquete, el champán, el cielo
- y el infierno, y el que dirán social.
<!-- -->
- En mí no, que en mí manda mi solo corazón,
- mi solo pensamiento; quien manda en mí soy yo.
<!-- -->
- Tú, flor de aristocracia; y yo, la flor del pueblo.
- Tú en ti lo tienes todo y a todos se
- lo debes, mientras que yo, mi nada a nadie se la debo.
<!-- -->
- Tú, clavada al estático dividendo ancestral,
- y yo, un uno en la cifra del divisor
- social somos el duelo a muerte que se acerca fatal.
<!-- -->
- Cuando las multitudes corran alborotadas
- dejando atrás cenizas de injusticias quemadas,
- y cuando con la tea de las siete virtudes,
- tras los siete pecados, corran las multitudes,
- contra ti, y contra todo lo injusto y lo inhumano,
- yo iré en medio de ellas con la tea en la mano.
