---
title: My poem
date: 2022-02-02T14:56:58+02:00
draft: false
author: Alex Gil
editor: Alex Gil
source: My imagination
---

- The library is pretty
- And so are books
- Deep
