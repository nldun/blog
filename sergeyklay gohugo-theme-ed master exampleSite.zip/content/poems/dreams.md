---
title: Dreams
date: 2022-02-01T14:56:58+02:00
lastmod: 2022-05-01T14:56:58+02:00
draft: false
author: Langston Hughes
editor: Alex Gil
source: Project Guttenberg
---

- Hold fast to dreams
- For if dreams die
- Life is a broken-winged bird
- That cannot fly.
- Hold fast to dreams
- For when dreams go
- Life is a barren field
- Frozen with snow.
